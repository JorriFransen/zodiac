require"config"

-- use shared sig generator
package.path = '../common/?.lua;' .. package.path
require"rand-sig"

